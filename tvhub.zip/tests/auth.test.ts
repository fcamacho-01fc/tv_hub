import request from 'supertest';
import mongoose from 'mongoose';
import { MongoMemoryServer } from 'mongodb-memory-server';
import { app } from '../src/app.js';
import { User } from '../src/models/user.model.js';
import { Session } from '../src/models/session.model.js';
import { hashPassword } from '../src/utils/password.js';
import { refreshTokenMatches } from '../src/utils/token-hash.js';

let mongo: MongoMemoryServer;

function cookie(response: request.Response, name: string): string {
  const rawCookies = response.headers['set-cookie'];
  const cookies = Array.isArray(rawCookies) ? rawCookies : rawCookies ? [rawCookies] : [];
  const header = cookies.find((value) => value.startsWith(`${name}=`));
  if (!header) throw new Error(`Missing ${name} cookie`);
  return header.split(';')[0];
}

beforeAll(async () => {
  mongo = await MongoMemoryServer.create();
  await mongoose.connect(mongo.getUri());
});

beforeEach(async () => {
  await User.deleteMany({});
  await Session.deleteMany({});
});

afterAll(async () => {
  await mongoose.disconnect();
  await mongo.stop();
});

test('register creates a USER, stores a hash, and starts a session', async () => {
  const response = await request(app).post('/api/auth/register').send({ email: 'student@example.com', password: 'StrongPass123!' }).expect(201);
  expect(response.body.user).toEqual(expect.objectContaining({ email: 'student@example.com', role: 'USER' }));
  expect(response.headers['set-cookie']).toHaveLength(2);
  const user = await User.findOne({ email: 'student@example.com' }).lean();
  expect(user?.passwordHash).not.toBe('StrongPass123!');
  expect(await Session.countDocuments({ userId: user?._id })).toBe(1);
});

test('register rejects a duplicate email', async () => {
  await request(app).post('/api/auth/register').send({ email: 'student@example.com', password: 'StrongPass123!' }).expect(201);
  const response = await request(app).post('/api/auth/register').send({ email: 'student@example.com', password: 'StrongPass123!' }).expect(409);
  expect(response.body.error.code).toBe('EMAIL_ALREADY_EXISTS');
});

test('login accepts valid credentials and rejects invalid credentials', async () => {
  await User.create({ email: 'student@example.com', passwordHash: await hashPassword('StrongPass123!'), role: 'USER' });
  await request(app).post('/api/auth/login').send({ email: 'student@example.com', password: 'StrongPass123!' }).expect(200);
  const response = await request(app).post('/api/auth/login').send({ email: 'student@example.com', password: 'wrong-password' }).expect(401);
  expect(response.body.error.code).toBe('INVALID_CREDENTIALS');
});

test('protected routes distinguish unauthenticated and forbidden users', async () => {
  await request(app).get('/api/users/me').expect(401);
  const login = await request(app).post('/api/auth/register').send({ email: 'student@example.com', password: 'StrongPass123!' }).expect(201);
  await request(app).get('/api/users/me').set('Cookie', cookie(login, 'accessToken')).expect(200);
  await request(app).get('/api/admin/demo').set('Cookie', cookie(login, 'accessToken')).expect(403);
});

test('ADMIN can access the administrative demonstration route', async () => {
  await User.create({ email: 'admin@example.com', passwordHash: await hashPassword('StrongPass123!'), role: 'ADMIN' });
  const login = await request(app).post('/api/auth/login').send({ email: 'admin@example.com', password: 'StrongPass123!' }).expect(200);
  await request(app).get('/api/admin/demo').set('Cookie', cookie(login, 'accessToken')).expect(200, { message: 'Admin access granted' });
});

test('refresh rotates the refresh token', async () => {
  const registration = await request(app).post('/api/auth/register').send({ email: 'student@example.com', password: 'StrongPass123!' }).expect(201);
  const oldRefresh = cookie(registration, 'refreshToken');
  const refreshed = await request(app).post('/api/auth/refresh').set('Cookie', oldRefresh).expect(200);
  const newRefresh = cookie(refreshed, 'refreshToken');
  expect(newRefresh).not.toBe(oldRefresh);
  const session = await Session.findOne();
  expect(session).not.toBeNull();
  expect(refreshTokenMatches(newRefresh.slice('refreshToken='.length), session!.refreshTokenHash)).toBe(true);
  expect(refreshTokenMatches(oldRefresh.slice('refreshToken='.length), session!.refreshTokenHash)).toBe(false);
  await request(app).post('/api/auth/refresh').set('Cookie', oldRefresh).expect(401);
  await request(app).post('/api/auth/refresh').set('Cookie', newRefresh).expect(200);
});

test('logout revokes the current session', async () => {
  const registration = await request(app).post('/api/auth/register').send({ email: 'student@example.com', password: 'StrongPass123!' }).expect(201);
  const refresh = cookie(registration, 'refreshToken');
  await request(app).post('/api/auth/logout').set('Cookie', refresh).expect(204);
  await request(app).post('/api/auth/refresh').set('Cookie', refresh).expect(401);
});

test('logout-all revokes every active session for the authenticated user', async () => {
  const first = await request(app).post('/api/auth/register').send({ email: 'student@example.com', password: 'StrongPass123!' }).expect(201);
  const second = await request(app).post('/api/auth/login').send({ email: 'student@example.com', password: 'StrongPass123!' }).expect(200);
  const firstRefresh = cookie(first, 'refreshToken');
  const secondRefresh = cookie(second, 'refreshToken');

  await request(app).post('/api/auth/logout-all').set('Cookie', cookie(first, 'accessToken')).expect(204);
  await request(app).post('/api/auth/refresh').set('Cookie', firstRefresh).expect(401);
  await request(app).post('/api/auth/refresh').set('Cookie', secondRefresh).expect(401);
});
