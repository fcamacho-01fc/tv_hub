import type { RequestHandler } from 'express';
import type { Role } from '../models/user.model.js';

export function authorize(...allowedRoles: Role[]): RequestHandler {
  return (request, response, next) => {
    if (!request.auth || !allowedRoles.includes(request.auth.role)) {
      response.status(403).json({ error: { code: 'FORBIDDEN', message: 'You do not have permission' } });
      return;
    }
    next();
  };
}
