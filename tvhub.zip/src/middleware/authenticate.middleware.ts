import type { RequestHandler } from 'express';
import { verifyAccessToken } from '../utils/jwt.js';

export const authenticate: RequestHandler = (request, response, next) => {
  const token = request.cookies.accessToken as string | undefined;
  if (!token) {
    response.status(401).json({ error: { code: 'UNAUTHORIZED', message: 'Authentication is required' } });
    return;
  }

  try {
    const payload = verifyAccessToken(token);
    request.auth = { userId: payload.sub, role: payload.role };
    next();
  } catch {
    response.status(401).json({ error: { code: 'UNAUTHORIZED', message: 'Invalid or expired access token' } });
  }
};
